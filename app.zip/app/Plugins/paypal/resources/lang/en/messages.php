<?php

return [
    'Payment Details' => 'Payment Details',
    'Payment with Paypal' => 'Payment with Paypal',
];